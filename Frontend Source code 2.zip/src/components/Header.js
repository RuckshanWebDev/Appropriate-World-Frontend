import React from 'react'
import './Header.css'

function Header() {
  return (

        <div className='header'>
            <img src='/images/header.jpg' />
        </div>

  )
}

export default Header
